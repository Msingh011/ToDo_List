import logo from "../media/logo.svg";
import mansi from "../media/mansi.png"


const media={logo, mansi,}

export default media